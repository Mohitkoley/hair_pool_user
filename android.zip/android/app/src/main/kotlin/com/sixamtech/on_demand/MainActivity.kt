package com.sixamtech.demandium.user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
